package com.example;

import static org.junit.Assert.assertEquals;


import org.junit.Test;

public class GestorCuidadosTest {
    

    @Test
    public void testFinalizarCuidado() {
        String resultadoEsperado= "FINALIZADO";
        GestorCuidados resultado= new GestorCuidados("Area 1", "2023 03 09", null, null);
        resultado.finalizarCuidado(resultadoEsperado);
        assertEquals(resultadoEsperado, resultado.getResultado());


        }   

    @Test
    public void testGetArea() {
      String resultadoArea= "Area 1";
      GestorCuidados Area= new GestorCuidados("Area 1", resultadoArea, null, null);
      Area.Area(resultadoArea);
      assertEquals(resultadoArea, Area.getArea());

    }


}
