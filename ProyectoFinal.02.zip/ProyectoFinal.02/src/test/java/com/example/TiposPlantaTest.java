package com.example;

import org.junit.Test;

public class TiposPlantaTest {
    @Test
    public void testGetNombre() {

    }

    @Test
    public void testGetTipo() {

    }
}
